import numpy as np

# Create a NumPy array
arr = np.array([[1,2], [2,3], [3,4]])

# Append a new element to the array
new_element = [2,5]
arr = np.concatenate((arr, new_element))

print(arr)