import torch
import torch.utils.data as data
import os
import pickle
import numpy as np
#import nltk
from PIL import Image
import os.path
import random
from torch.autograd import Variable
import torch.nn as nn
import math
import scipy.io as scio  # 需要用到scipy库
import random
import matplotlib.pyplot as plt
import scipy.io



# Environment Encoder

class Encoder(nn.Module):
	def __init__(self):
		super(Encoder, self).__init__()
		self.encoder = nn.Sequential(nn.Linear(2800, 512),nn.PReLU(),nn.Linear(512, 256),nn.PReLU(),nn.Linear(256, 128),nn.PReLU(),nn.Linear(128, 28))
			
	def forward(self, x):
		x = self.encoder(x)
		return x


class Decoder(nn.Module):
	def __init__(self):
		super(Decoder, self).__init__()
		self.decoder = nn.Sequential(nn.Linear(28, 128),nn.PReLU(),nn.Linear(128, 256),nn.PReLU(),nn.Linear(256, 512),nn.PReLU(),nn.Linear(512, 2800))
	def forward(self, x):
		x = self.decoder(x)
		return x




#N=number of environments; NP=Number of Paths 
# N 改成50，从50-99，NP 改20
N = 10001
NP=20
Q = Encoder()
Q.load_state_dict(torch.load('models/cae_encoder.pkl'))

D = Decoder()
D.load_state_dict(torch.load('models/cae_decoder.pkl'))

if torch.cuda.is_available():
	Q.cuda()
	D.cuda()




def obs_rand_gen(n):
	obstacles=np.zeros((n,2),dtype=np.float32)
	for i in range(0,n):
		x = random.uniform(-15,15)
		y = random.uniform(-15,15)
		obstacles[i][0] = x
		obstacles[i][1] = y
	return obstacles


def obs_gen(n):
	obc=np.zeros((N,7,2),dtype=np.float32)
	temp=np.fromfile('dataset/obs.dat')
	obs=temp.reshape(len(temp)//2,2)

	temp=np.fromfile('dataset/obs_perm2.dat',np.int32)
	perm=temp.reshape(77520,7)
	#print(perm)
	#print(obs)
	#obs[perm[0][0]]
	
	obstacles=np.zeros((n,2),dtype=np.float32)
	for i in range(0,n):
		x = obs[perm[0][i]][0]
		y = obs[perm[0][i]][1]
		obstacles[i][0] = x
		obstacles[i][1] = y
	#print(obstacles)
	return obstacles


def gen_obs28(wi):
	Q = Encoder()
	Q.load_state_dict(torch.load('/home/haichao/hzz/MPNet-master/MPNet-change2/models/cae_encoder.pkl'))
	if torch.cuda.is_available():
		Q.cuda()
	temp=np.fromfile('/home/haichao/hzz/MPNet-master/MPNet-change2/dataset/obs_cloud/obc'+str(wi)+'.dat')
	temp=temp.reshape(len(temp)//2,2)
	obstacles=np.zeros((1,2800),dtype=np.float32)
	obstacles[0]=temp.flatten()
	inp=torch.from_numpy(obstacles)
	inp=Variable(inp).cuda()
	output=Q(inp)
	output=output.data.cpu()
	obs_28=output.numpy()
	obs_28 = obs_28.tolist()
	#print(obs_28)
	return obstacles
		
def obs_zhankai(obs):
	n = len(obs)	
	temp=np.zeros((1400,2),dtype=np.float32)
	for i in range(0,n):
		for j in range(0,200):
			temp[i*200+j][0] = random.uniform(obs[i][0]-2.5,obs[i][0]+2.5)
			temp[i*200+j][1] = random.uniform(obs[i][1]-2.5,obs[i][1]+2.5)
	return temp
	
	
obs = obs_gen(7)
#print(len(obs))



# 要加载多少obs		
obs_rep=np.zeros((N,28),dtype=np.float32)

#temp=np.fromfile('dataset/obs_cloud/obc'+str(1)+'.dat')
#temp=temp.reshape(len(temp)//2,2)
temp = obs_zhankai(obs)
scipy.io.savemat('temp2.mat', mdict={'temp': temp})
wi = 0
temp=np.fromfile('/home/haichao/hzz/MPNet-master/MPNet-change2/dataset/obs_cloud/obc'+str(wi)+'.dat')
temp = temp.reshape(-1,2)
scipy.io.savemat('temp1400.mat', mdict={'temp': temp})
obstacles=np.zeros((1,2800),dtype=np.float32)
obstacles[0]=temp.flatten()


obs1 = gen_obs28(0)
obs2 = obstacles
print(len(obs1[0]))
print(len(obs2[0]))

x1 = 0
x2 = 0
y1 = 0
y2 = 0
for i in range(0,2800):
	x1 += obs1[0][i]
	x2 += obs2[0][i]
print(x1-x2)




"""




print(np.size(obstacles))

plt.figure()

for i in range(0,1400):
	plt.scatter(temp[i][0],temp[i][1],color='b')
for i in range(0,7):
	plt.scatter(obs[i][0],obs[i][1],color = 'r')
plt.xticks(np.arange(-15,15,5))
plt.yticks(np.arange(-15,15,5))
#plt.show()


inp=torch.from_numpy(obstacles)
inp=Variable(inp).cuda()
output=Q(inp)
output=output.data.cpu()
#obs_rep[1]=output.numpy()
obs_28=output.numpy()
obs_28 = obs_28.tolist()
print(obs_28)

#print(obs_rep[i])
#file_name = 'obs/obs'+str(1)+'.mat'
#print("工作空间：",i)
#scio.savemat(file_name, {'obs':obs_rep[i]}) 

"""





