import argparse
import torch
import torch.nn as nn
import numpy as np
import os
import pickle
from data_loader_change import load_test_dataset 
from model import MLP 
from torch.autograd import Variable 
import math
import time

size=5.0

# Load trained model for path generation
mlp = MLP(32, 2) # simple @D
mlp.load_state_dict(torch.load('models/mlp_100_4000_PReLU_ae_dd450.pkl'))

if torch.cuda.is_available():
	mlp.cuda()

#load test dataset
obc,obstacles, paths, path_lengths= load_test_dataset() 

def to_var(x, volatile=False):
	if torch.cuda.is_available():
		x = x.cuda()
	return Variable(x, volatile=volatile)

def main(args):
	# Create model directory
	if not os.path.exists(args.model_path):
		os.makedirs(args.model_path)
	start=np.zeros(2,dtype=np.float32)
	goal=np.zeros(2,dtype=np.float32)


	w = 5 # workspace_number
	s = 1 # path_number
	#start=paths[w][s][0]
	#goal=paths[w][s][path_lengths[w][s]-1]
	print("当前工作空间：",w," 当前path：",s)
	# 手动
	start[0] = -12
	start[1] = -16
	goal[0] = 18
	goal[1] = 10


	start1=torch.from_numpy(start)
	goal1=torch.from_numpy(goal)
	##goal point

	##obstacles
	obs=obstacles[w]
	obs=torch.from_numpy(obs)
	path=[]
	print(start)
	for i in range(0,5):
		inp1=torch.cat((obs,start1,goal1))
		inp1=to_var(inp1)
		start1=mlp(inp1)
		start1=start1.data.cpu()
		path.append(start1)
		print(start1.data)


	print(goal)


	





if __name__ == '__main__':
	parser = argparse.ArgumentParser()
	parser.add_argument('--model_path', type=str, default='./models/',help='path for saving trained models')
	parser.add_argument('--no_env', type=int, default=50,help='directory for obstacle images')
	parser.add_argument('--no_motion_paths', type=int,default=2000,help='number of optimal paths in each environment')
	parser.add_argument('--log_step', type=int , default=10,help='step size for prining log info')
	parser.add_argument('--save_step', type=int , default=1000,help='step size for saving trained models')

	# Model parameters
	parser.add_argument('--input_size', type=int , default=32, help='dimension of the input vector')
	parser.add_argument('--output_size', type=int , default=2, help='dimension of the input vector')
	parser.add_argument('--hidden_size', type=int , default=256, help='dimension of lstm hidden states')
	parser.add_argument('--num_layers', type=int , default=4, help='number of layers in lstm')

	parser.add_argument('--num_epochs', type=int, default=100)
	parser.add_argument('--batch_size', type=int, default=28)
	parser.add_argument('--learning_rate', type=float, default=0.001)
	args = parser.parse_args()
	print(args)
	main(args)

