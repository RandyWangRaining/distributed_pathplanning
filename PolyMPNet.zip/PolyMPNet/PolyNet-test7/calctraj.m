function [yarray0, dyarray0, tarray] = calctraj(via,dt,tacc)
ptlen = size(via,2);
y0 = via(1,:);
% mstraj 可以生成轨迹
% 机器人工具箱提供了函数mstraj()来产生一条基于中间点的多段多轴的轨迹。
% 例如2轴经过4个中间点的轨迹就可以这样产生：
%其中via就是4个中间点的坐标，mstraj的第一个参数就是要通过的中间点，第二个参数就是每个轴的最大的速度
%所组成的向量，第三个参数是每个段的间隔所组成的向量，第四个参数是初始的轴坐标，第六个参数是取样周期，
%最后一个参数是加速时间。mstraj函数会返回一个矩阵，行表示时间间隔，列表示坐标值。

yarray0 = mstraj(via(2:end,:),ones(1,ptlen),[],y0,dt,tacc); % row vector for each xr
yarray0 = [y0;yarray0];
dyarray0 = [diff(yarray0)./dt;zeros(1,ptlen)];
tarray = 0:dt:(size(yarray0,1)-1)*dt;
end