How to use:

- run `main_trajectory_planning.m`  to see the planning simulation.

- run `main_robot_control.m` to see the control simulation.

Requirement:

1. [MOSEK-MATLAB](https://github.com/star2dust/MOSEK-MATLAB) or [CVX](https://github.com/cvxr/CVX)
2. [Robotics-Toolbox](https://github.com/star2dust/Robotics-Toolbox).

