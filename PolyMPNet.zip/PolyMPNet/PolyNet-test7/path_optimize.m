clear;
close all;
clc;
load path_cube
load path_poly
% plot(path_cube(:,1),path_cube(:,2));
% hold on
% figure(1)

plot(path_poly(2));
hold on
plot(path_poly(3));
hold on
plot(path_poly(4));
hold on;
node1=[1,2];
node2=[2,4];

[a,b,c]=Ab_transer(node1,node2)


[A2,B2]=poly_transer(path_poly(2,:))
[A3,B3]=poly_transer(path_poly(3,:))
[A4,B4]=poly_transer(path_poly(4,:))

l1=size(A2,1);
l2=size(A3,1);
l3=size(A4,1);
l=l1+l2+l3;
z1=path_cube(1,:);
zd = [path_cube(2,:),path_cube(3,:),path_cube(4,:)];
A=zeros(l,6);
A(1:l1,1:2)=A2;
A(l1+1:l1+l2,3:4)=zeros(l2,2);
A(l1+l2+1:l,5:6)=A4;

B3=zeros(l2,1);
b=[B2;B3;B4];
% [z,~,flag] = fmincon(@(z) (z-zd)*(z-zd)',zd,[],[],[],[],lb,ub,@(z) mycon(z,Ap,bp,lc,lm,config_num));
options = optimoptions('fmincon','Algorithm','interior-point','Display','iter');
%                                                    Az <= b  
% [z,fval,exitflag,output] = fmincon(@(z)fun1(z,z1),zd,[],[],[],[],[],[],[]);
[z,fval,exitflag,output] = fmincon(@(z)fun1(z,z1),zd,A,b,[],[],[],[],[]);
fval
z
plot(z1(1,1),z1(1,2),'r.')
hold on
plot(z(1,3),z(1,4),'r.')
hold on 
plot(z(1,5),z(1,6),'r.')
hold on


function f1 = fun3(x)
f = -x(1) - 2*x(2) + (1/2)*x(1)^2 + (1/2)*x(2)^2;
end

function f=fun1(z,z1)
f=(z(1,1:2)-z1)*(z(1,1:2)-z1)'+(z(1,3:4)-z(1,1:2))*(z(1,3:4)-z(1,1:2))'+(z(1,5:6)-z(1,3:4))*(z(1,5:6)-z(1,3:4))';
end


function [a,b,c]=Ab_transer(node1,node2)    %给定两点
if node1(1,1)==node2(1,1)
a=1;
b=0;
c=node1(1,1);
else
a=(node1(1,2)-node2(1,2))/(node1(1,1)-node2(1,1));
b=-1;
c=a*node1(1,1)-node1(1,2);
end
end

function [A,B]=poly_transer(poly1)
verts1=poly1.Vertices;           %得到交集多边形的顶点
center_x=mean(verts1(:,1));
center_y=mean(verts1(:,2));
poly_center=[center_x,center_y];
for i=1:size(verts1,1)
    if isnan(verts1(i,1))
        verts1=verts1(1:i-1,:);
        break;
    end
end
verts1=[verts1;verts1(1,:)];
A=[];
B=[];
for i=1:size(verts1,1)-1
    [a,b,c]=Ab_transer(verts1(i,:),verts1(i+1,:));
    if a*poly_center(1,1)+b*poly_center(1,1)>c
        a=-a;
        b=-b;
        c=-c;
    end
    A=[A;a,b];
    B=[B;c];
end
end
