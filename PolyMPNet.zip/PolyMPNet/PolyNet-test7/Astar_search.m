function [paths,path_node]= Astar_search(points)
paths = [];
% 先获取起点和终点

node_num = size(points,1);
son = zeros(node_num,node_num);
g = zeros(node_num,1);
h = zeros(node_num,1);
f = zeros(node_num,1);
expand = zeros(node_num,1);
% 下面获取每个节点的儿子
for i = 1:node_num
    x = points(i,1);
    y = points(i,2);
    for j = 1:node_num
       if i~= j && x == points(j,3) && y == points(j,4)
           k = 1;
           while son(i,k) ~= 0
                k = k+1;
           end
           son(i,k) = j;
       end
    end
end

queue = zeros(node_num,1); %队列存待扩展节点
father = zeros(node_num,1);
queue_empty = 0;
cur = 1;
queue(1) = 1;
expand(1) = 1;

while cur ~= node_num && ~queue_empty
f_min = 10000;
pre_node = cur;
for i = 1:node_num
    if queue(i) ~= 0 && f(i) < f_min
        f_min = f(i);
        cur = i; %取出当前f最小的节点
    end
end
%father(cur) = pre_node;
queue(cur) = 0;
%扩展这个节点
k = 1;
while son(cur,k) ~= 0
    gg = dist(cur,son(cur,k),points) + g(cur,1);
    hh = dist(node_num,son(cur,k),points);
    ff = gg+hh;
    if expand(son(cur,k)) == 0
        queue(son(cur,k)) = 1; % 加入队列
        g(son(cur,k),1) = gg;
        h(son(cur,k),1) = hh;
        f(son(cur,k),1) = ff;
        expand(son(cur,k)) = 1;
        father(son(cur,k)) = cur;
    elseif expand(son(cur,k)) == 1 && ff < f(son(cur,k))
        f(son(cur,k)) = ff;
        father(son(cur,k)) = cur;
    end
    k = k + 1;
end

queue_empty = 1;
for i = 1:node_num
   if queue(i) ~= 0
      queue_empty = 0; 
   end
end

end

cur_node = size(father,1);
path_node = [];
while cur_node~= 1
    path_node = [path_node;cur_node];
    cur_node = father(cur_node,1);
end
paths = [paths;points(1,1), points(1,2)];
for i = size(path_node,1):-1:1
    paths = [paths;points(path_node(i,1),1), points(path_node(i,1),2)];
end
draw_path(paths);
end



function d = dist(i,j,points)
x1 = points(i,1);
y1 = points(i,2);

x2 = points(j,1);
y2 = points(j,2);

d = sqrt((x1-x2)^2 + (y1-y2)^2);
end


function draw_path(paths)

for i = 1:size(paths,1)-1
    x1 = paths(i,1);
    y1 = paths(i,2);
    x2 = paths(i+1,1);
    y2 = paths(i+1,2);
    hold on
    line([x1,x2],[y1,y2],'LineWidth',1,'color','b') ;
end

end
