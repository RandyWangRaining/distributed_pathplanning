function [point,flag,poly,config_rand,feasible_polys_append]=one_step_main_trajectory_planning(xo,tnode,window,xo_nerual)
%% 
%close all
%clear
%% requirements
% given obstacle field O, start configuration z_s with centroid s and destination g for the formation's centroid.
import iris.inflate_region.*
import iris.drawing.*
import iris.thirdParty.polytopes.*
import pkgMechanics.*

figure(3);
% constants
lcx = 1.2; lcy = 1.2; lcz = 0.2; % size of object 
lmx = 1.2; lmy = 1.2; lmz = 0.3; lm_b = 0.15; % size of platform
% obstacles 
for i = 1:size(xo,1)
    obst(i) = pkgMechanics.RigidCuboid(1,xo(i,:),[5,5,1]);
end
% obstacles cell
obstcell = createobstcell(obst);
% range 地图尺寸

% range.lb = [window(1,1);window(1,2)];
% range.ub = [window(2,1);window(2,2)];

range.lb = [-15;-15];
range.ub = [15;15];


%% initialize an empty graph
nodez = []; % z vector in row
nodepoly = []; % polytope struct
nodezinpoly = {}; % z index
% initialize edges
edgez = []; % z index
%% configuration
%a0 = 0.7; w0 = 0.5;
a0 = 0.7; w0 = 0.5;
config = [a0,w0];
config_num = [];
feasible_polys=[];
%% generate start and goal
% start = [1.5,1.5];     % start position
% goal = [8.5,8.5];     % goal position 
start = tnode(1,:);     % start position
t=size(tnode,1);
goal = tnode(t,:);     % goal position 
[nodez, nodepoly, nodezinpoly,config_num,feasible_polys]= startxgoal(nodez,nodepoly,nodezinpoly,[start;goal],config,obstcell,range,[lcx,lcy,lcz],[lmx,lmy,lmz],config_num,xo,feasible_polys);
%% detemine z
z0 = [start,config];
[xr0,xc0,xm0]= z2x(z0,[lcx,lcy,lcz],[lmx,lmy,lmz]);
%% build object 
cub = pkgMechanics.RigidCuboid(1,xc0,[lcx,lcy,lcz]);
%% build platforms
for i=1:4
    plat(i) = pkgMechanics.RigidCuboid(1,xm0(i,:),[lmx,lmy,lmz]);
end
%% build robot arms
Tc2e = lc2Tce([lcx,lcy,lcz],1); % => constants
Tm2b = transl([lm_b,0,lmz/2]); % => constants
mdl_puma560
for i=1:4
    rob(i) = SerialLink('name','robot');
    copy(rob(i),p560); rob(i).name = ['robot',num2str(i)];
    rob(i).base = x2T(xm0(i,:))*Tm2b;
    q0(i,:) = rob(i).ikine6s(x2T(xc0)*Tc2e{i},'ru');% right hand elbow up
end
%% visualize map
draw_obs_poly(nodepoly,obstcell.vert,window);
drawplat3d(nodez,[lcx,lcy,lcz],[lmx,lmy,lmz],config_num)
%% add goal node to graph
[nodez,nodezinpoly,nodegrid,edgez,config_num,feasible_polys]=creategraph2(nodez,nodepoly,nodezinpoly,edgez,1,config,range,[lcx,lcy,lcz],[lmx,lmy,lmz],config_num,xo,feasible_polys);
[noderoute,polyroute] = shortestpath(nodez,nodezinpoly,nodegrid,1,2);
%% generate random nodes

% counter = 0;
flag = isempty(noderoute);
if flag
    nodenum = 1;
    [nodez,nodepoly,nodezinpoly,config_num,feasible_polys] = randnode(nodez,nodepoly,nodezinpoly,nodenum,config,obstcell,range,[lcx,lcy,lcz],[lmx,lmy,lmz],config_num,xo_nerual,feasible_polys);
    % create undirected graph and its edges 
    
    [nodez,nodezinpoly,nodegrid,edgez,config_num,feasible_polys]=creategraph2(nodez,nodepoly,nodezinpoly,edgez,1,config,range,[lcx,lcy,lcz],[lmx,lmy,lmz],config_num,xo,feasible_polys);
    [noderoute,polyroute] = shortestpath(nodez,nodezinpoly,nodegrid,1,2);
%     counter = counter + 1;
end

draw_obs_poly(nodepoly(polyroute),[],window); 
drawplat3d(nodez(noderoute,:),[lcx,lcy,lcz],[lmx,lmy,lmz],config_num(noderoute,:));
% rnodez=nodez(noderoute,:);
% rconfig_num=config_num(noderoute,:);
config_num_len=size(config_num,1);
feasible_poly_len=size(feasible_polys,1);
if flag && size(nodez,1) == 3
    point = [];
    poly = [];
    config_rand=[];
    feasible_polys_append=[];
elseif ~flag && size(nodez,1) == 3 % 起点和终点连通，中间点为1，把终点也加进去
    point = [nodez(size(nodez,1),1),nodez(size(nodez,1),2)];
    point = [point;nodez(size(nodez,1)-1,1),nodez(size(nodez,1)-1,2)];
    poly = [nodepoly(1);nodepoly(2)];
    config_rand=[config_num(config_num_len);config_num(config_num_len-1)];
    feasible_polys_append=[feasible_polys(feasible_poly_len);feasible_polys(feasible_poly_len-1)];
% elseif flag && size(nodez,1) == 5  %可行点产生的多边形连通了起点多边形与终点多边形，将交集的点与可行点，终点都加入ponint。
%     point = [nodez(4,1:2)];
%     point = [point;nodez(3,1:2)];
%     point = [point;nodez(5,1:2)];
%     point = [point;nodez(2,1:2)];
%     point = [nodez(size(nodez,1)-1,1),nodez(size(nodez,1)-1,2)];
%     point = [point;nodez(size(nodez,1),1),nodez(size(nodez,1),2)];
%     poly = [nodepoly(1);nodepoly(2)];
%     config_rand=[config_num(4);config_num(3);config_num(5);config_num(2)];
elseif flag && size(nodez,1) == 4
    point = [nodez(4,1:2)];
    point = [point;nodez(3,1:2)];
%     point = [nodez(size(nodez,1),1),nodez(size(nodez,1),2)];
    poly = [nodepoly(1);nodepoly(2)];  
    config_rand=[config_num(4);config_num(3)];
    feasible_polys_append=[feasible_polys(4);feasible_polys(3)];
else
    point = [];
    poly = [];
    config_rand=[];
    feasible_polys_append=[];
end
size(config_rand,1)
size(feasible_polys_append,1)
hold on


%%%%%%%%% the above is the whole global planning part %%%%%%%%%%%
end
function obstacle = createobstcell(obstcub)
n_obs=length(obstcub);
for i=1:n_obs
    obstacle_pts(:,:,i) = obstcub(i).verticesStates.position(1:2,1:4);
end
% reset obstacles vertices in its convexhull (iris requires obstacles to be convex)
obsidx = cell(1,size(obstacle_pts,3));
obstacle.vert = cell(1,size(obstacle_pts,3));
for j = 1:n_obs
    obs = obstacle_pts(:,:,j);
    if size(obs, 2) > 1
        if size(obs, 2) > 2
            obsidx{j} = convhull(obs(1,:), obs(2,:));
        else
            obsidx{j} = [1,2,1];
        end
    end
    obstacle.vert{j} = obs(:,obsidx{j})';
    obstacle.calc{j} = obs(:,obsidx{j});
end
% obstacles cell
obstacle.poly = obstacle.vert{1}';
for i=2:size(obstacle.vert,1)
    obstacle.poly = [obstacle.poly,NaN(2,1),obstacle.vert{i}'];
end
end

function [nodez, nodepoly, nodezinpoly,config_num,feasible_polys]= startxgoal(nodez,nodepoly,nodezinpoly,randnode,nodeconfig,obstacle,range,lc,lm,config_num,xo,feasible_polys)
% set nodez to all zero
znum = size(nodez,1);
polynum = length(nodepoly);
% generate nodes outside obstacles
randnum = size(randnode,1);
for i=1:randnum
    % generate ploytope
    randpoly = polytope(obstacle.calc,randnode(i,:)',range);
    % check whether formation exists in a polytope      
    [flag,poly_center,config_rand,feasible_poly]=mink_judge(randpoly,randpoly,xo);
    randz=[randnode(i,:),nodeconfig]; 
    if flag==1
        % add this location to nodelocation list
        nodez = [nodez;randz];
        config_num = [config_num;config_rand];
        feasible_polys=[feasible_polys;feasible_poly];
        nodepoly = [nodepoly,randpoly];
        nodezinpoly{polynum+i} = znum+i;
        
        %%%%%
%         hold on
%         plot(randlocation(1),randlocation(2),'go');
%         plot(randz(1),randz(2),'r*');
%         draw_obs_poly(randpoly,[],range);
%         drawplat3d(randz);
%         hold off
        %%%%%
    end

        %%%%%
%         hold on
%         plot(randlocation(1),randlocation(2),'go');
%         plot(randz(1),randz(2),'r*');
%         draw_obs_poly(randpoly,[],range);
%         drawplat3d(randz);
%         hold off
        %%%%%
    end
end

function flag = innodepoly(randlocation,nodepoly)
polynum = length(nodepoly);
count = 0;
for i=1:polynum
    if nodepoly(i).A*randlocation-nodepoly(i).b<=0
        count = count+1;
    end
end
if count==0
    flag = false;
else
    flag = true;
end
end
