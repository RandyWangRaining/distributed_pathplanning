function [flag,f_type,poly_center,feasible_poly]=twopolytope_judge(poly1,poly2)
tic;
f_type=0;
poly_center=[0,0];    %设置初始值
feasible_poly=[];
verts1=Abtoverts(poly1);
verts2=Abtoverts(poly2);           %获取多边形的顶点
poly1=polyshape(verts1);
poly2=polyshape(verts2);
polyout = intersect(poly1,poly2);  %求该两个多边形的交集
verts1=polyout.Vertices;           %得到交集多边形的顶点

flag=1;
if size(verts1,1)==0               %若交集多边形为空，返回0，退出
    flag=0;
    return;
end


for formation=1:5
formation
%选择编队的种类
switch(formation)
    case 1
    verts2=[-1.5,-0.5;-1.5,0.5;
    -0.5,1.5;0.5,1.5;
    1.5,0.5;1.5,-0.5;
    0.5,-1.5;-0.5,-1.5;];          %十字形
    case 2
    verts2=[0,0;0,1;5,1;5,0];          %横条
    case 3
    verts2=[0,0;0,5;1,5;1,0];          %竖条
    case 4
%     verts2=[1.5,2.5;2.5,2.5;
%         2.5,1.5;0.5,-0.5;
%         -1.5,-2.5;-2.5,-2.5;
%         -2.5,-1.5;-0.5,0.5];
    verts2=[1.5,2.5;2.5,2.5;
        2.5,1.5;
        -1.5,-2.5;-2.5,-2.5;
        -2.5,-1.5];
    case 5
    verts2=[-1.5,2.5;-2.5,2.5;
        -2.5,1.5;
        1.5,-2.5;2.5,-2.5;
        2.5,-1.5];
    
end

poly1=polyshape(verts1);
poly2=polyshape(verts2);       %根据顶点生成多边形
% plot(poly1)
% % xlim([-10 20]);
% % ylim([-10 20]);
% hold on
% plot(poly2)
center=mean(poly1.Vertices);      %计算poly1的中心点
verts=relative_vert(poly2);       %得到poly2的相对形状
vert_set=place_verts(poly1,verts); %以poly1的每个顶点为中心，放置poly2

%对每一条边进行偏移
d_num=0;
v_num=size(verts2,1);
Vertices=[poly1.Vertices;poly1.Vertices(1,:)];  %将poly1的顶点构成闭环
vert_set=[vert_set;vert_set(1:v_num,:)];            %将放置在poly1各顶点的多个poly2顶点集合构成闭环
endpoint=[];
for i=1:size(Vertices,1)-1
    d_max=0;
    for j=1:size(poly2.Vertices)     
        if issameside(Vertices(i,:),Vertices(i+1,:),center,vert_set(v_num*(i-1)+j,:))    %判断顶点和中心点是否在直线的同一侧
            d=distance(vert_set(v_num*(i-1)+j,:)',Vertices(i,:)',Vertices(i+1,:)');                               
            if d>d_max  %找到距离该边最远的点
                d_max=d;
                d_num=v_num*(i-1)+j;       %记录最远的点的序号
            end   
        end
    end
    twovert=[vert_set(d_num,:);
    vert_set(d_num+v_num,:)];       %将目前编队的顶点和下一编队对应的顶点组成集合
	endpoint=[endpoint;twovert];
%     plot(twovert(:,1),twovert(:,2))     %连接成线段
end

verts_result=[];
endpoint=[endpoint;endpoint(1:2,:)];    %构成闭环
for i=1:2:size(endpoint,1)-3       %依次计算两线段的交点
    vert=crossnode(endpoint(i,:),endpoint(i+1,:),endpoint(i+2,:),endpoint(i+3,:));
    verts_result=[verts_result;vert];
end

poly3=polyshape(verts_result);        %绘制出找到的边界多边形  

% plot(poly3);
% hold on;
if flag==1
    verts1=polyout.Vertices;           %得到交集多边形的顶点
    center_x=mean(verts1(:,1));
    center_y=mean(verts1(:,2));
    poly_center=[center_x,center_y];
end
flag=verify(poly1,verts_result,verts);  %验证交集多边形里是否能放编队
if flag==2
    f_type=formation;
    feasible_poly=poly3;
    break;
end

% text(15,15,num2str(flag),'FontSize',20);
% hold on;
toc;
% s=strcat(num2str(toc),'s');
% text(-5,-5,s,'FontSize',20);
% hold on;
end
end

function d=distance(P,Q1,Q2)
    d = abs(det([Q2-Q1,P-Q1]))/norm(Q2-Q1);
end

function verts=relative_vert(poly)  %求多边形各顶点相对于多边形中心点的位置
verts=[];
center=mean(poly.Vertices); 
verts=poly.Vertices-center;
% for i=1:size(poly.Vertices,1)     
%     vert=poly.Vertices(i,:)-center;
%     verts=[verts;vert];    
% end
end

function vert_set=place_verts(poly,verts)   %将小多边形放置在大多边形的顶点上
vert_set=[];
for i=1:size(poly.Vertices,1)
    a=poly.Vertices(i,:)+verts;
    vert_set=[vert_set;a];
    poly3=polyshape(a);
%     plot(poly3);
%     hold on;
end
end

function flag = issameside(P1,P2,Q1,Q2)   %判断两点是否在一条直线的同侧
P1Q1 = Q1 - P1; P1P2 = P2 - P1; P1Q2 = Q2 - P1;
P1Q1(:,3) = 0; P1P2(:,3) = 0; P1Q2(:,3) = 0;
a1 = cross(P1Q1,P1P2);a2 = cross(P1Q2,P1P2);
ans = -1 * min(sign(sign(dot(a1,a2))-1),0);
if ans==0
    flag=1;
else
    flag=0;
end
end

function node=crossnode(P1,P2,Q1,Q2)  %计算两条直线的交点
x1=P1(1,1);
y1=P1(1,2);
x2=P2(1,1);
y2=P2(1,2);
x3=Q1(1,1);
y3=Q1(1,2);
x4=Q2(1,1);
y4=Q2(1,2);
x0 = ((x3-x4) * (x2*y1 - x1*y2) - (x1-x2) * (x4*y3 - x3*y4)) / ((x3-x4) * (y1-y2) - (x1-x2) * (y3-y4));
y0 = ((y3-y4) * (y2*x1 - y1*x2) - (y1-y2) * (y4*x3 - y3*x4)) / ((y3-y4) * (x1-x2) - (y1-y2) * (x3-x4));
node=[x0,y0];

end

function flag=judge_square(vertexs,poly)                  %判断正方形是否在多边形里面
for i=1:size(vertexs,1) 
    TFin = isinterior(poly,vertexs(i,:));
    if TFin==0
        flag=0;
        return
    end
end
flag=1;
end

function flag=verify(poly,verts_result,verts)
flag=1;
for i=1:size(verts_result,1)
    a=verts_result(i,:)+verts;
    if judge_square(a,poly)
        flag=2;
        return;
    end
end
end

function verts=Abtoverts(poly)
A=poly.A;
b=poly.b;
vert=lcon2vert(A, b);
k = convhull(vert(:,1), vert(:,2));
verts=[];
for i=1:size(vert,1)
    verts=[verts;vert(k(i,1),:)];
    
end
end















