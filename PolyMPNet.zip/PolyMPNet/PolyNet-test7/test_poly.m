% figure(11);
% [paths,path_node]= Astar_search(points);
% path_node=[path_node;1];
% path_cube=points(path_node,1:2);
% config_cube=config_num(path_node);
% path_len=size(path_cube,1);
% for i=1:path_len
% draw_cube(path_cube(i,1:2),config_cube(i));
% end
% time=toc;
% polys=node_feasible_polys((path_node(1:path_len-1)-1));
% poly_num=size(polys,1);
% polys_order=[];
% cube_order=[];
% for i=2:poly_num
%     polys_order=[polys_order;polys(poly_num-i+1)];
% end
% cube_len=size(config_cube,1);
% for i=1:cube_len
%     cube_order=[cube_order;config_cube(cube_len-i+1)]; 
% end
% [final_path,final_path_len]=plot_optimize_path(paths,polys_order);
% figure(12);
% plot(obstacle_poly);
% hold on;
% for i=1:size(final_path,1)
% draw_cube(final_path(i,1:2),cube_order(i));
% end




verts2=[-1.5,2.5;-2.5,2.5;
    -2.5,1.5;
    1.5,-2.5;2.5,-2.5;
    2.5,-1.5];

window=[0,0;0,30;30,30;30,0];
window_poly=polyshape(window);
verts2_poly=polyshape(verts2);
plot(window_poly);
hold on 
plot(verts2_poly);
% verts2=verts2+15;
flag=isInobstacle(verts2,window_poly)


function flag=isInobstacle(node,polys)        %判断是否在障碍物里，在障碍物里返回1。
flag=0;
for i=1:size(polys,1)
    TFin = isinterior(polys(i,:),node);
    if TFin==1
        flag=1;
        return;
    end
end
end

