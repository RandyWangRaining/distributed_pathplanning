function hcanvas = draw_new(region,obstacle_poly,windows,start_and_goal)
import iris.thirdParty.polytopes.*
% h = figure(2);
% cla
% lb = range.lb;
% ub = range.ub;

figure(11);
axis([0, 90, 0, 90]);
set(gcf,'Position',[1500 300 1000 800]);
window = [windows(size(windows,1)-1,1),windows(size(windows,1)-1,2);
    windows(size(windows,1),1),windows(size(windows,1),2)
    ];


if size(window,1)==2
lb = [window(1,1);window(1,2)];
ub = [window(2,1);window(2,2)];
else
lb = window.lb;
ub = window.ub;
end
hold on
% plot(obstacle_poly);
hold on
draw_cube(start_and_goal,1);

for i=1:length(region)
    if iscell(region)
        regionstruct = [region{:}];
    else
        regionstruct = region;
    end
    A = regionstruct(i).A;
    b = regionstruct(i).b;
%     C = regionstruct(i).C;
%     d = regionstruct(i).d;
    for j = 1:size(A,1)-4
        % a'x = b
        % set x(1) = 0
        % x(2) = b / a(2)
        ai = A(j,:);
        bi = b(j);
        if ai(2) == 0
            x0 = [bi/ai(1); 0];
        else
            x0 = [0; bi/ai(2)];
        end
        u = [0,-1;1,0] * ai';
        pts = [x0 - 1000*u, x0 + 1000*u];
        hold on
        hcanvas.region(i).bound = plot(pts(1,:), pts(2,:), 'm--', 'LineWidth', 1.5); %��ɫ��
    end
    if ~isempty(A)
        V = lcon2vert(A, b); % ��ö���
        k = convhull(V(:,1), V(:,2)); %����˳��
        hold on
        hcanvas.region(i).interior = plot(V(k,1), V(k,2), 'ro-', 'LineWidth', 2); % ��ɫ��
    end
%     th = linspace(0,2*pi,100);
%     y = [cos(th);sin(th)];
%     x = bsxfun(@plus, C*y, d);
%     plot(x(1,:), x(2,:), 'b-', 'LineWidth', 2);
end
end

function draw_window(window,color)

x1 = window(1,1);
y1 = window(1,2);
x2 = window(2,1);
y2 = window(2,2);
hold on
line_w=0.5;
line([x1,x2],[y1,y1],'LineWidth',line_w,'color',color) ;
hold on
line([x1,x1],[y1,y2],'LineWidth',line_w,'color',color);
hold on
line([x1,x2],[y2,y2],'LineWidth',line_w,'color',color);
hold on
line([x2,x2],[y1,y2],'LineWidth',line_w,'color',color);
end
