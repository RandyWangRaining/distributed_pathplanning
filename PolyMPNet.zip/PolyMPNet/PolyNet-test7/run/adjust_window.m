% close all
% clc
% clear
% 
% 
% figure;
% map_size=[0,90];
% 
% 
% 
% hold on
% 
% node1=[5,5];
% window1=[node1;node1(1,1)+30,node1(1,2)+30];
% adjust_window1(window1,map_size);
% hold on
% node2=[80,10];
% window2=[node2;node2(1,1)+30,node2(1,2)+30];
% adjust_window1(window2,map_size);
% hold on 
% node3=[80,80];
% window3=[node3;node3(1,1)+30,node3(1,2)+30];
% adjust_window1(window3,map_size);
% hold on 
function window=adjust_window(window,map_size)
map_size=[map_size(1,1),map_size(1,1);map_size(1,2),map_size(1,2)];
% plot_window(window);
%对不完全在地图内的滑动窗口进行调整
%第一种情况，只有横坐标超出范围，做横向平移调整
%第二种情况，只有纵坐标超出范围，做竖直平移调整
%第三种情况，两者都超出范围，都需要调整。

%H_adjust
if window(2,1)>map_size(2,1)
    window(2,1)=map_size(2,1);
    window(1,1)=window(2,1)-30;

elseif window(1,1)<map_size(1,1)
    window(1,1)=map_size(1,1)
    window(2,1)=window(1,1)+30;
end
%V_adjust
if window(2,2)>map_size(2,2)
    window(2,2)=map_size(2,2);
    window(1,2)=window(2,2)-30;
elseif window(1,2)<map_size(1,2)
    window(1,2)=map_size(1,2)
    window(2,2)=window(1,2)+30;
end

% plot_window(window);
end



function window = gen_window(start)
x1 = start(1) - 5;
y1 = start(2) - 5;
    window = [ 
        x1,     y1;
        x1 + 30,y1 + 30;
        ];
end

function plot_window(window)
verts1=[window(1,1),window(1,2)];
verts2=[window(1,1),window(2,2)];
verts3=[window(2,1),window(2,2)];
verts4=[window(2,1),window(1,2)];
verts=[verts1;verts2;verts3;verts4];
poly_w=polyshape(verts);
plot(poly_w);
end