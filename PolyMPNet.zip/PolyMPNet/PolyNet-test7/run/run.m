close all
clear

%% ��ʼ��

% �����ϰ���
map_size = [0,90]; % ��ͼ��С
obs_num = 25;  % �ϰ�������
% obs = gen_rand_obs(obs_num,map_size);
obs=load('obs25.mat');
obs=obs.obs;
% obs(2,1)=34;
% obs(18,1)=34;

%load obs
tic;

error = [];
% ������յ�?
obstacle_poly=create_obstacle(obs(:,1:2),2.5);

big_obstacle_poly=create_obstacle(obs(:,1:2),3.5);
% start_and_goal = [
%     5,5;
%     map_size(2)-15-rand*5,map_size(2)-5-rand*5
%     ];
start_and_goal = [
    70,10;
    65+rand*5,map_size(2)-10-rand*5
    ];
tnode_start = [start_and_goal(1,1),start_and_goal(1,2)];
goal = [start_and_goal(2,1),start_and_goal(2,2)];
points = []; % Ŀǰ�Ѿ���֪���ĵ�
config_num=[];
node_feasible_polys=[];
polys = []; % Ŀǰ��֪poly
windows = [];
points = [points;tnode_start,tnode_start];
config_num=[config_num;1];
%node_feasible_polys
%window = []; % ���ڵ�λ��
window = [start_and_goal(1,1)-5,start_and_goal(1,2)-5; start_and_goal(1,1)+25,start_and_goal(1,2)+25];
window=adjust_window(window,map_size);
% window = [map_size(1),map_size(1); 30,30]; % ��ʼ����
windows = [windows;window];
%% ��ʼ����
figure(11);
axis([map_size(1), map_size(2), map_size(1), map_size(2)]);
% init_draw(obs);
plot(obstacle_poly);
set(gcf,'Position',[1500 300 1000 800]);
%draw_cube(start_and_goal,1);
% ����յ㲻��window��
while 1
%������������������


%draw_new([],obstacle_poly,windows,start_and_goal);
% plot(randpoint(1),randpoint(2),'.','Color','g','MarkerSize',30);
% plot(near_point(1),near_point(2),'.','Color','b','MarkerSize',30);
% line([randpoint(1),near_point(1)],[randpoint(2),near_point(2)],'LineWidth',4,'color','r') ;


draw_window(window,'b')
draw_points(points)

xo_nerual = obs_filter(obs,window); % ����������ڵ��ϰ���xo
xo_poly = obs_filter_poly(obstacle_poly,window);
if tnode_start(1,1)<goal(1,1)
    if tnode_start(1,2)<goal(1,2)
        tnode_goal = gen_tnode_goal(window,big_obstacle_poly,1,1); % �ڴ������������Ͻǵ���ʱ�յ�
    else
        tnode_goal = gen_tnode_goal(window,big_obstacle_poly,1,-1); % �ڴ������������Ͻǵ���ʱ�յ�
    end
else
    if tnode_start(1,2)<goal(1,2)
        tnode_goal = gen_tnode_goal(window,big_obstacle_poly,-1,1); % �ڴ������������Ͻǵ���ʱ�յ�
    else
        tnode_goal = gen_tnode_goal(window,big_obstacle_poly,-1,-1); % �ڴ������������Ͻǵ���ʱ�յ�
    end
end

if size(xo_poly,1)==0
    window_verts=[window(1,1),window(1,2);window(1,1),window(2,2);
        window(2,1),window(2,2);window(2,1),window(2,2)];
    window_verts_poly=polyshape(window_verts);
    points = [points;tnode_goal,tnode_start];    
    config_num=[config_num;1];
    node_feasible_polys=[node_feasible_polys;window_verts_poly];
end


% tnode_goal = gen_tnode_goal(window,obstacle_poly); % �ڴ������������Ͻǵ���ʱ�յ�
tnode = [tnode_start;tnode_goal];
if ~in_window(goal,window)
    figure(2);
   tnode_lenth=size(tnode,1);
   tnode(tnode_lenth,:)=goal;
   [rnodez,rconfig_num,flag,feasible_polys]= main_trajectory_planning(xo_poly,tnode,window,xo_nerual);
   father_node=tnode_start;
   rnodez_len=size(rnodez,1);
   config_num=[config_num;rconfig_num(2:rnodez_len)];
   node_feasible_polys=[node_feasible_polys;feasible_polys(2:rnodez_len)];
   for i = 2:rnodez_len
%         points = [points;rnodez(i,1),rnodez(i,2),points(size(points,1),1),points(size(points,1),2)];
       points = [points;rnodez(i,1),rnodez(i,2),father_node(1,1),father_node(1,2)];      
       father_node=rnodez(i,:);
   end
   break;
end

[xo_poly,tnode]=big_to_small(window,xo_poly,tnode);
[point,flag,poly,config_rand,feasible_polys_append]=one_step_main_trajectory_planning(xo_poly,tnode,window,xo_nerual); % ����������
if size(config_rand,1)~=size(feasible_polys_append,1)
   break; 
end


big_polys=[];
close 3;
if size(point,1)~=0
    [xo_poly,point,big_polys]=small_to_big(window,xo_poly,point,feasible_polys_append);
end


for i = 1:size(point,1)
points = [points;point(i,:),tnode_start];
tnode_start = [point(i,1),point(i,2)];
end
if size(config_rand,1)~=size(big_polys,1)
   break; 
end
config_num=[config_num;config_rand];
node_feasible_polys=[node_feasible_polys;big_polys];
polys = [polys;poly];
% �����ٽ��յ�������
randpoint = gen_randpoint(goal,20);
%disp("�����������randpoint")
%randpoint = ginput(1);L_or_R
% �ҵ�����������������ĵ�?
near_point = find_near_point(points,randpoint);
% �õ�ǰ�����������?
tnode_start = near_point;
window = gen_window(tnode_start,randpoint);

window=adjust_window(window,map_size);

windows = [windows;window];
end
hold on 

% text(45,80,int2str(time));




%%
% ���ɰ���n���ϰ����map
function obs = gen_rand_obs(n,map_size)
obs = [];
s = map_size(2);
x = 0; y = 0;
for i = 1:n
    x = rand*s;
    y = rand*s;
    while x < 5 || y < 5
        x = rand*s;
        y = rand*s;
    end
    while x > map_size(2)-5 || y > map_size(2)-5
        x = rand*s;
        y = rand*s;
    end
    obs = [obs;x,y,0.5,0,0,0];
end

end

function xo = obs_filter(obs,window)
xo = [];
%obs(1,1) = 1; obs(1,2) = 2;
for i = 1:size(obs,1)
    if obs(i,1) >= window(1,1) && obs(i,1) <= window(2,1) && obs(i,2) >= window(1,2) && obs(i,2) <= window(2,2)
        xo = [xo;obs(i,1),obs(i,2),0.5,0,0,0];
    end
end

end

function xo = obs_filter_poly(obstacle_poly,window)
xo = [];
%obs(1,1) = 1; obs(1,2) = 2;
window1=[window(1,1),window(1,2);window(1,1),window(2,2);
    window(2,1),window(2,2);window(2,1),window(1,2);];
poly_window=polyshape(window1);
for i=1:size(obstacle_poly,1)
    verts=obstacle_poly(i,:).Vertices;
    fg=judge_square(verts,poly_window);
    if fg==1
        center_x=mean(verts(:,1));
        center_y=mean(verts(:,2));
        poly_center=[center_x,center_y,0.5,0,0,0];
        xo=[xo;poly_center];
    end
end

end


function tnode_goal = gen_tnode_goal(window,obstacle_poly,L_or_R,D_or_U)
flag=1;
if L_or_R==-1
    dx=0;
elseif L_or_R==1
    dx=20;
end
if D_or_U==-1
    dy=0;
elseif D_or_U==1
    dy=20;
end
while flag
x = rand*10+dx;
y = rand*10+dy;
x = x + window(1,1);
y = y + window(1,2);
tnode_goal = [x,y];
flag=isInobstacle(tnode_goal,obstacle_poly);
end

end

function draw_window(window,color)

x1 = window(1,1);
y1 = window(1,2);
x2 = window(2,1);
y2 = window(2,2);
hold on
line_w=0.5;
line([x1,x2],[y1,y1],'LineWidth',line_w,'color',color) ;
hold on
line([x1,x1],[y1,y2],'LineWidth',line_w,'color',color);
hold on
line([x1,x2],[y2,y2],'LineWidth',line_w,'color',color);
hold on
line([x2,x2],[y1,y2],'LineWidth',line_w,'color',color);
end

function flag = in_window(goal,window)
flag = true;
if goal(1) >= window(1,1) && goal(1) <= window(2,1) && goal(2) >= window(1,2) && goal(2) <= window(2,2)
    flag = false;
end
end

function window = gen_window(tnode_start,randpoint)
% ��ȡ��㵽randpoint�ķ���
temp = randpoint - tnode_start;
if temp(1)>=0
    i = 1;
else 
    i = -1;
end
if temp(2)>=0
    j = 1;
else 
    j = -1;
end

% ��ȡ���������Ĵ��ڽǵ�1
node1_x = tnode_start(1) - i*5;
node1_y = tnode_start(2) - j*5;
% ��ȡ���������Ĵ��ڽǵ�1
node2_x = node1_x + i*30;
node2_y = node1_y + j*30;

window = [ 
    min(node1_x,node2_x),min(node1_y,node2_y);
    max(node1_x,node2_x),max(node1_y,node2_y);
    ];

end

function randpoint = gen_randpoint(goal,R)
% �յ㸽��
% x = rand*(R/2) - R;
% y = rand*(R/2) - R;
% randpoint = [goal(1)+x, goal(2)+y];
% ȫͼ���?
x = rand*90;
y = rand*90;
randpoint = [x,y];
hold on
%plot(randpoint(1),randpoint(2),'.','Color','g','MarkerSize',30);
end

function near_point = find_near_point(points,randpoint)
n = size(points,1);
len = 10000000;
near_point = [];
for i = 1:n
    dis = sqrt( (randpoint(1,1) - points(i,1))^2 +  (randpoint(1,2) - points(i,2))^2 );
    if dis<len
        len = dis;
        near_point = [points(i,1),points(i,2)];
    end
end

end


function draw_windows(windows)
n = size(windows,1)/2;

for i = 1:n-1
    draw_window([windows(2*i-1,:);windows(2*i,:)],'b')
end
draw_window([windows(2*n-1,:);windows(2*n,:)],'r');


end

function draw_points(points)

for i = 1:size(points,1)
    hold on
    plot(points(i,1),points(i,2),'.','Color','g','MarkerSize',30);
end

% for i = 1:size(points,1)-1
%     x1 = points(i,1);
%     y1 = points(i,2);
%     x2 = points(i+1,1);
%     y2 = points(i+1,2);
%     line([x1,x2],[y1,y2],'LineWidth',4,'color','r') ;
% end

for i = 1:size(points,1)
    x1 = points(i,1);
    y1 = points(i,2);
    x2 = points(i,3);
    y2 = points(i,4);
    hold on
    line([x1,x2],[y1,y2],'LineWidth',1,'color','r') ;
end
end


function window=adjust_window(window,map_size)
map_size=[map_size(1,1),map_size(1,1);map_size(1,2),map_size(1,2)];
% plot_window(window);
%�Բ���ȫ�ڵ�ͼ�ڵĻ������ڽ��е���
%��һ�������ֻ�к����곬����Χ��������ƽ�Ƶ���?
%�ڶ��������ֻ�������곬����Χ������ֱƽ�Ƶ���?
%��������������߶�������Χ������Ҫ������?

%H_adjust
if window(2,1)>map_size(2,1)
    window(2,1)=map_size(2,1);
    window(1,1)=window(2,1)-30;

elseif window(1,1)<map_size(1,1)
    window(1,1)=map_size(1,1)
    window(2,1)=window(1,1)+30;
end
%V_adjust
if window(2,2)>map_size(2,2)
    window(2,2)=map_size(2,2);
    window(1,2)=window(2,2)-30;
elseif window(1,2)<map_size(1,2)
    window(1,2)=map_size(1,2)
    window(2,2)=window(1,2)+30;
end

% plot_window(window);
end


function [xo,tnode]=big_to_small(window,xo,tnode)  %�����ͼ������任��������������
%���ϰ������ĵ㣬����յ������ȥ�����������½ǵĵ㣬�õ��������?
xo(:,1:2)=xo(:,1:2)-window(1,:)-15;
tnode=tnode-window(1,:)-15;
end

function [xo,tnode,big_polys]=small_to_big(window,xo,tnode,small_poly) %��������������任�����ͼ����
xo(:,1:2)=xo(:,1:2)+window(1,:)+15;
tnode=tnode+window(1,:)+15;
big_polys=[];
for i=1:size(small_poly,1)
    small_verts=small_poly(i).Vertices;
    big_verts=small_verts+window(1,:)+15;
    big_poly=polyshape(big_verts);
    big_polys=[big_polys;big_poly];
end
end



function vertexs=grow_square(node,s)      %将node作为中心点，产生�?个边长为s的矩形，返回顶点
nodes=[];
motion=[s,s;s,-s;-s,-s;-s,s];
for i=1:4
    nodes=[nodes;node];   
end
vertexs=nodes+motion;
end

function obstacle_poly=create_obstacle(xo,s)      %以xo为中心点，产生障碍物
obstacle_poly=[];
for i=1:size(xo,1)
    verts=grow_square(xo(i,:),s);
    poly=polyshape(verts);
    obstacle_poly=[obstacle_poly;poly];    
end
end

function flag=isInobstacle(node,polys)        %判断是否在障碍物里，在障碍物里返�?1�?
flag=0;
for i=1:size(polys,1)
    TFin = isinterior(polys(i,:),node);
    if TFin==1
        flag=1;
        return;
    end
end
end

function flag=judge_square(vertexs,poly)                  %判断正方形是否在多边形里�?
for i=1:size(vertexs,1) 
    TFin = isinterior(poly,vertexs(i,:));
    if TFin==1
        flag=1;
        return
    end
end
flag=0;
end
