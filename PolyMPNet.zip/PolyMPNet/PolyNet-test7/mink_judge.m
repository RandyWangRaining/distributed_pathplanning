function [flag,poly_center,config_rand,feasible_poly]=mink_judge(poly1,poly2,xo)
flag_play=1;
[flag_normal,f_type,poly_center,feasible_poly]=twopolytope_judge(poly1,poly2);  %如果flag_normal为2，则可以放置编队
if flag_normal==1       %如果flag_normal为1,表明两多边形能产生交集，但交集内不足以容纳编队
[flag_play,f_type]=collision_detection(xo(:,1:2),poly_center); %在交集多边形的中心点放置编队，检测是否会与障碍物相碰撞。
poly_verts=grow_square(poly_center,0.5);
poly1=polyshape(poly_verts);
feasible_poly=[feasible_poly;poly1];
end        
config_rand=f_type;   
%plot(poly_center(1,1),poly_center(1,2),'g.','markersize',30)
flag=0;
if flag_normal==2||flag_play==0
    flag=1;
end
end
    
    

 function [flag,formation]=collision_detection(xo,node)
flag=0;
formation=0;
for formation=1:5     %选择编队形状
switch(formation)
    case 1
    verts2=[-1.5,-0.5;-1.5,0.5;
    -0.5,1.5;0.5,1.5;
    1.5,0.5;1.5,-0.5;
    0.5,-1.5;-0.5,-1.5;];          %十字形
    case 2
    verts2=[0,0;0,1;5,1;5,0];          %横条
    case 3
    verts2=[0,0;0,5;1,5;1,0];          %竖条
    case 4
%     verts2=[1.5,2.5;2.5,2.5;
%         2.5,1.5;0.5,-0.5;
%         -1.5,-2.5;-2.5,-2.5;
%         -2.5,-1.5;-0.5,0.5];
    verts2=[1.5,2.5;2.5,2.5;
        2.5,1.5;
        -1.5,-2.5;-2.5,-2.5;
        -2.5,-1.5];
    case 5
    verts2=[-1.5,2.5;-2.5,2.5;
        -2.5,1.5;
        1.5,-2.5;2.5,-2.5;
        2.5,-1.5];
end

obstacle_poly=create_obstacle(xo);   %创建障碍物
formation_verts=verts2+node;         %在指定点放置编队

for i=1:size(formation_verts,1) 
    flag=isInobstacle(formation_verts(i,:),obstacle_poly); %判断点是否在障碍物里
    if flag==1
        break;
    end
end
if flag==1
    break;
end

end
end





function vertexs=grow_square(node,s)      %将node作为中心点，产生一个边长为s的矩形，返回顶点
nodes=[];
motion=[s,s;s,-s;-s,-s;-s,s];
for i=1:4
    nodes=[nodes;node];   
end
vertexs=nodes+motion;
end

function obstacle_poly=create_obstacle(xo)      %以xo为中心点，产生障碍物
obstacle_poly=[];
for i=1:size(xo,1)
    verts=grow_square(xo(i,:),2.5);
    poly=polyshape(verts);
    obstacle_poly=[obstacle_poly;poly];    
end
end

function flag=isInobstacle(node,polys)        %判断是否在障碍物里，在障碍物里返回1。
flag=0;
for i=1:size(polys,1)
    TFin = isinterior(polys(i,:),node);
    if TFin==1
        flag=1;
        return;
    end
end
end