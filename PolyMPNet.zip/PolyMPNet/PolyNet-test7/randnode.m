function [nodez, nodepoly, nodezinpoly,config_num,feasible_polys]= randnode(nodez,nodepoly,nodezinpoly,nodenum,nodeconfig,obstacle,range,lc,lm,config_num,xo,feasible_polys)
import iristools.*
import iris.drawing.*

%%python导入
% clear classes
% P = py.sys.path;
% if count(P,'/home/haichao/hzz/matlab/PolyMPNet/mdn') == 0
%    insert(P,int32(0),'/home/haichao/hzz/matlab/PolyMPNet/mdn');
% end
% obj = py.importlib.import_module('draw_test');
% py.importlib.reload(obj);
% py.draw_test.draw_test()

%%
% set nodez to all zero
znum = size(nodez,1);
polynum = length(nodepoly);
% generate nodes outside obstacles
ctr=1; % counter
wi = 1;
while (ctr<=nodenum)
    % generate random two number in range of map's border
    randlocation = [rand* (range.ub(1)-range.lb(1)) + range.lb(1);
        rand* (range.ub(2)-range.lb(2)) + range.lb(2)];
    
%     A = input('����������꣺\n');
%     if A ~= 0
%         randlocation = A;
%         hold on
%         plot(randlocation(1),randlocation(2),'.','Color','g','MarkerSize',30);
%         hold on 
%     end
%     obs = gen_obs28(34);

    
    if size(nodepoly,2) == 2
        data = gen_42data(wi,nodepoly(1),[nodez(2,1),nodez(2,2)],xo);
    else
        data = gen_42data(wi,nodepoly(size(nodepoly,2)),[nodez(2,1),nodez(2,2)],xo);
    end
    




    %[x,y] = ginput(1);
    x = data(1);
    y = data(2);
    hold on
    plot(x,y,'.','Color','g','MarkerSize',30);
    hold on
    A = [x;y];
    if A ~= 0
        randlocation = A;
    end
    
    flag_obs = true;
    for i = 1:size(obstacle.vert,2)
        obstacle.poly = obstacle.vert{i}';
        if inpolygon(randlocation(1),randlocation(2),obstacle.poly(1,:),obstacle.poly(2,:))
            flag_obs = false;
        end
    end
    % if this node is not inside any obstacle
    if flag_obs
        % chech if inside a existing polytope
%         if ~innodepoly(randlocation,nodepoly)
            % generate ploytope
            randpoly = polytope(obstacle.calc,randlocation,range);
            draw_region_2d(randpoly,[],range); 
            % check whether formation exists in a polytope
            [randz,fg,config_rand] = formationP2z(randpoly,[randlocation',nodeconfig],range,lc,lm);
            [~,~,~,feasible_poly]=mink_judge(randpoly,randpoly,xo);
            if fg==1
                % add this location to nodelocation list
                nodez = [nodez;randz];
                feasible_polys=[feasible_polys;feasible_poly];
                config_num = [config_num;config_rand];
                nodepoly = [nodepoly,randpoly];
                nodezinpoly{polynum+ctr} = znum+ctr;
                ctr=ctr+1;
            end
%         end
    end
end
end

function flag = innodepoly(randlocation,nodepoly)
polynum = length(nodepoly);
count = 0;
for i=1:polynum
    if nodepoly(i).A*randlocation-nodepoly(i).b<=0
        count = count+1;
    end
end
if count==0
    flag = false;
else
    flag = true;
end
end


function data = gen_42data(wi,poly,goal,xo)    
    verts = transpoly(poly);
    obs = gen_obs28(wi,xo);
    data42 = obs';
    
    for i = 1:6
        data42 = [data42;verts(i,1)];
        data42 = [data42;verts(i,2)];
    end
    data42 = [data42;goal'];
    P = py.sys.path;
    if count(P,'/home/haichao/hzz/matlab/PolyMPNet/mdn') == 0
       insert(P,int32(0),'/home/haichao/hzz/matlab/PolyMPNet/mdn');
    end

    obj = py.importlib.import_module('pridict');
    py.importlib.reload(obj);

    %data42 = [-75.9877243041992;-36.3739624023438;-35.2661514282227;-26.6194114685059;9.40821743011475;-29.6317520141602;-42.8149032592773;-12.1770858764648;-2.06218242645264;-90.8029708862305;-90.8897018432617;-65.4634857177734;91.2786483764648;35.6538124084473;23.4177303314209;50.8988304138184;-7.33890438079834;46.0881996154785;37.5631141662598;-90.7436141967773;49.0610580444336;-43.3589820861816;36.6424942016602;41.8767127990723;-33.6515731811523;-23.7444915771484;-15.9982309341431;-51.5327796936035;-16;-20;2.03242881038960;-20;1.70237385367568;4.30127455450079;-4.33641623759976;20;-16;20;-16;0;17.9999960352177;10.0000000251071];

    
    % 均值点
%     x = 0;
%     y = 0;
%     for i = 1:50
%         temp = py.pridict.pridict(data42');
%         x = x + temp{1};
%         y = y + temp{2};
%     end
%     x_mean = x/50;
%     y_mean = y/50; 
%     data = [x_mean,y_mean];
    
    temp = py.pridict.pridict(data42');
    x = 0+temp{1};
    y = 0 + temp{2};
    data = [x,y];
    
end







function obs = gen_obs28(wi,xo)
P = py.sys.path;
if count(P,'/home/haichao/hzz/MPNet-master/MPNet-change2') == 0
   insert(P,int32(0),'/home/haichao/hzz/MPNet-master/MPNet-change2');
end

obj = py.importlib.import_module('gen_obs28');
py.importlib.reload(obj);
% wi = 10001;

% xo = handle_xo()



% xo=floor(xo);
xo=xo(:,1:2);
xo=xo(:);
xo=xo';
obs_temp = py.gen_obs28.gen_obs28(1,xo);
% obs_temp = py.gen_obs28.gen_obs28(int32(wi));
obs_temp = obs_temp{1};

for i = 1:28
    obs(i) = obs_temp{i};
end

end




function verts=transpoly(poly1)
verts=Abtoverts(poly1);
while size(verts,1)<6     %当多变形的顶点个数不满6个
    verts_circle=[verts;verts(1,:)];
    d_max=0;
    d_num=0;
    for k=1:size(verts_circle)-1                          %计算连续两个顶点的距离，找出最长的边
        d=distance(verts_circle(k,:),verts_circle(k+1,:));
        if d>d_max
            d_max=d;
            d_num=k;
        end
    end
    center=verts_circle(d_num,:)+verts_circle(d_num+1,:);
    center=center/2;
    verts=verts_insert(verts,d_num+1,center);                                 %取这条边的中点，按顺序插入顶点的集合中           
end
end


function verts=Abtoverts(poly)
A=poly.A;
b=poly.b;
vert=lcon2vert(A, b);
k = convhull(vert(:,1), vert(:,2));
verts=[];
for i=1:size(vert,1)
    verts=[verts;vert(k(i,1),:)];
    
end
end


function sets=verts_insert(verts,num,value)                   %在数组制定位置插入一个元素
sets=[];
len=size(verts,1);
j=0;
for i=1:len+1
    if i==num
        sets(i,:)=value;
        continue;
    end
    j=j+1;
    sets(i,:)=verts(j,:);
end
end