function callback_silent(varargin)
% A dummy callback which does nothing
end
