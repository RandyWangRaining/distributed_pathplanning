function [final_path,final_path_len]=plot_optimize_path(path_node,polys)
figure(12);
path_len=size(path_node,1);
plot(polys);
hold on 
plot(path_node(:,1),path_node(:,2),'r-');
hold on
start=path_node(1,:);
goal=path_node(path_len,:);
[A,B,nodes]=optimize_path(polys);
[z,fval] = fmincon(@(z)fun3(z,start,goal,polys),nodes,A,B,[],[],[],[],[]);
z_len=size(z,1);
final_path=reshape(z,2,z_len/2)';
final_path=[start;final_path;goal];
plot(final_path(:,1),final_path(:,2),'g-');
hold on
final_path_len=sqrt(fval);
end

function [A,B,nodes]=optimize_path(polys)
poly_num=size(polys,1);
%A=zeros(l,2*variable_num);
A=[];
B=[];
nodes=[];
l=1;      %A����ӵ�����
j=1;
for i=1:poly_num
    [A1,B1]=poly_transer(polys(i));
    l1=size(A1,1);
    center=get_poly_center(polys(i));
    A(l:l+l1-1,j:j+1)=A1;
    B=[B;B1];
    nodes=[nodes,center];
    l=l+l1;
    j=j+2;
end
nodes=nodes';
end

function f=fun1(z,start,goal)
f=(z(1,1:2)-start)*(z(1,1:2)-start)'+(z(1,3:4)-z(1,1:2))*(z(1,3:4)-z(1,1:2))'+(z(1,5:6)-z(1,3:4))*(z(1,5:6)-z(1,3:4))'+(goal-z(1,5:6))*(goal-z(1,5:6))';
end

function f=fun2(z,start,goal)
start=start';
goal=goal';
f=(z(1:2)-start)'*(z(1:2)-start)+(z(3:4)-z(1:2))'*(z(3:4)-z(1:2))+(z(5:6)-z(3:4))'*(z(5:6)-z(3:4))+(z(7:8)-z(5:6))'*(z(7:8)-z(5:6))+(goal-z(7:8))'*(goal-z(7:8));
end

function f=fun3(z,start,goal,polys)
poly_num=size(polys,1);
start=start';
goal=goal';
f=(z(1:2)-start)'*(z(1:2)-start);
j=3;
for i=1:poly_num-1
    f=f+(z(j:j+1)-z(j-2:j-1))'*(z(j:j+1)-z(j-2:j-1));
    j=j+2;
end
j=j-2;
f=f+(goal-z(j:j+1))'*(goal-z(j:j+1));
%f=(z(1:2)-start)'*(z(1:2)-start)+(z(3:4)-z(1:2))'*(z(3:4)-z(1:2))+(z(5:6)-z(3:4))'*(z(5:6)-z(3:4))+(z(7:8)-z(5:6))'*(z(7:8)-z(5:6))+(goal-z(7:8))'*(goal-z(7:8));
end

function [a,b,c]=Ab_transer(node1,node2)    %给定两点
if node1(1,1)==node2(1,1)
a=1;
b=0;
c=node1(1,1);
else
a=(node1(1,2)-node2(1,2))/(node1(1,1)-node2(1,1));
b=-1;
c=a*node1(1,1)-node1(1,2);
end
end

function poly_center=get_poly_center(poly1)
verts1=poly1.Vertices;           %得到交集多边形的顶点
for i=1:size(verts1,1)
    if isnan(verts1(i,1))
        verts1=verts1(1:i-1,:);
        break;
    end
end
center_x=mean(verts1(:,1));
center_y=mean(verts1(:,2));
poly_center=[center_x,center_y];
end

function [A,B]=poly_transer(poly1)
verts1=poly1.Vertices; 
poly_center=get_poly_center(poly1);
for i=1:size(verts1,1)
    if isnan(verts1(i,1))
        verts1=verts1(1:i-1,:);
        break;
    end
end
verts1=[verts1;verts1(1,:)];
A=[];
B=[];
for i=1:size(verts1,1)-1
    [a,b,c]=Ab_transer(verts1(i,:),verts1(i+1,:));
    if a*poly_center(1,1)+b*poly_center(1,2)>c
        a=-a;
        b=-b;
        c=-c;
    end
    A=[A;a,b];
    B=[B;c];
end
end