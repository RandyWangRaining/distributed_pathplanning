import torch

import numpy as np

import random
from torch.autograd import Variable
import torch.nn as nn

import scipy.io as scio  # 需要用到scipy库

# Environment Encoder

class Encoder(nn.Module):
	def __init__(self):
		super(Encoder, self).__init__()
		self.encoder = nn.Sequential(nn.Linear(2800, 512),nn.PReLU(),nn.Linear(512, 256),nn.PReLU(),nn.Linear(256, 128),nn.PReLU(),nn.Linear(128, 28))
			
	def forward(self, x):
		x = self.encoder(x)
		return x
	
def obs_gen(n,wi):
	N = 100
	obc=np.zeros((N,7,2),dtype=np.float32)
	temp=np.fromfile('/home/haichao/hzz/MPNet-master/MPNet-change2/dataset/obs.dat')
	obs=temp.reshape(len(temp)//2,2)

	temp=np.fromfile('/home/haichao/hzz/MPNet-master/MPNet-change2/dataset/obs_perm2.dat',np.int32)
	perm=temp.reshape(77520,7)
	#print(perm)
	#print(obs)
	#obs[perm[0][0]]
	
	obstacles=np.zeros((n,2),dtype=np.float32)
	for i in range(0,n):
		x = obs[perm[wi][i]][0]
		y = obs[perm[wi][i]][1]
		obstacles[i][0] = x
		obstacles[i][1] = y
	#print(obstacles)
	xo = scio.loadmat("/home/haichao/hzz/MPNet-master/MPNet-change2/xo.mat")
	xo = xo["xo"]
	
	for i in range(0,n):
		obstacles[i][0] = xo[i][0]
		obstacles[i][1] = xo[i][1]
	print(obstacles)
	return obstacles	
	
def obs_zhankai(obs):
	n = len(obs)	
	temp=np.zeros((1400,2),dtype=np.float32)
	for i in range(0,n):
		for j in range(0,200):
			if i < 5: 
				temp[i*200+j][0] = random.uniform(obs[i][0]-2.5,obs[i][0]+2.5)
				temp[i*200+j][1] = random.uniform(obs[i][1]-2.5,obs[i][1]+2.5)
			else:

				temp[i*200+j][0] = temp[(i-1)*200+j][0]
				temp[i*200+j][1] = temp[(i-1)*200+j][1]
	return temp
	
	
	
def handle_xo(xo):
	#xo=np.array(xo)
	print(type(xo))
	print(xo)		
# 给一个工作空间编号wi，返回obs_28数据
def gen_obs28(wi,xo):
	Q = Encoder()
	Q.load_state_dict(torch.load('./models/cae_encoder.pkl',map_location=torch.device('cpu')))
	if torch.cuda.is_available():
		Q.cuda()
	#temp=np.fromfile('/home/haichao/hzz/MPNet-master/MPNet-change2/dataset/obs_cloud/obc'+str(wi)+'.dat')
	#temp=np.fromfile('/home/haichao/hzz/MPNet-master/MPNet-change2/dataset/obs_cloud/obc1.dat')
	#xo = handle_xo(xo);

	xo=np.array(xo)
	xo=xo.reshape(-1,2)
	temp = obs_zhankai(xo)

	#temp=temp.reshape(len(temp)//2,2)
	obstacles=np.zeros((1,2800),dtype=np.float32)
	obstacles[0]=temp.flatten()
	inp=torch.from_numpy(obstacles)
	inp=Variable(inp)
	output=Q(inp)
	output=output.data.cpu()
	obs_28=output.numpy()
	obs_28 = obs_28.tolist()
	print(obs_28)
	return obs_28

#gen_obs28(0)
data = np.ones((7,2),dtype=np.float32)
out = np.array(gen_obs28(1,data)).reshape(-1)
print(out)
print('ok')
