clc
clear;
% 重载Python模块
clear classes


P = py.sys.path;
% if count(P,'/home/haichao/hzz/matlab/py联动/mdn4') == 0
%    insert(P,int32(0),'/home/haichao/hzz/matlab/py联动/mdn4');
% end
% 
% obj = py.importlib.import_module('pridict');
% py.importlib.reload(obj);
%py.draw_test.draw_test()



% P = py.sys.path;
% if count(P,'/home/haichao/hzz/MPNet-master/MPNet-change2') == 0
%    insert(P,int32(0),'/home/haichao/hzz/MPNet-master/MPNet-change2');
% end
% 
% obj = py.importlib.import_module('gen_obs28');
% py.importlib.reload(obj);
% wi = 10001;
% obs_temp = py.gen_obs28.gen_obs28(int32(wi));
% obs_temp = obs_temp{1};
% for i = 1:28
%     obs(i) = obs_temp{i};
% end

P = py.sys.path;
if count(P,'/home/haichao/hzz/matlab/PolyMPNet/mdn') == 0
   insert(P,int32(0),'/home/haichao/hzz/matlab/PolyMPNet/mdn');
end

obj = py.importlib.import_module('pridict');
py.importlib.reload(obj);

data42 = [-75.9877243041992;-36.3739624023438;-35.2661514282227;-26.6194114685059;9.40821743011475;-29.6317520141602;-42.8149032592773;-12.1770858764648;-2.06218242645264;-90.8029708862305;-90.8897018432617;-65.4634857177734;91.2786483764648;35.6538124084473;23.4177303314209;50.8988304138184;-7.33890438079834;46.0881996154785;37.5631141662598;-90.7436141967773;49.0610580444336;-43.3589820861816;36.6424942016602;41.8767127990723;-33.6515731811523;-23.7444915771484;-15.9982309341431;-51.5327796936035;-16;-20;2.03242881038960;-20;1.70237385367568;4.30127455450079;-4.33641623759976;20;-16;20;-16;0;17.9999960352177;10.0000000251071];

x = 0;
y = 0;
for i = 1:50
    temp = py.pridict.pridict(data42');
    x = x + temp{1};
    y = y + temp{2};
end
x_mean = x/50;
y_mean = y/50;
