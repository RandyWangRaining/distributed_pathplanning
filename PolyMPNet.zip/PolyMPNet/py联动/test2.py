import numpy as np

def fun():
	print("hello matlab")
